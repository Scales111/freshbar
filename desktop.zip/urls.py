from django.urls import path, re_path
from . import views
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from django.views.generic import TemplateView



urlpatterns = [
    path('api/login', views.login.as_view(), name='login'),
    path('api/profile', views.profile.as_view(), name='profile'),
    path('api/register', views.register.as_view(), name='register'),
    path('api/tasks', views.get_tasks, name='get_tasks'),
    path('api/submit-answer', views.submit_answer.as_view(), name='submit_answer'),
    path('api/user-answers/<str:userId>', views.user_answers_view, name='user-answers'),
    path('api/get-user-answer?userId=<str:userId>&taskId=<str:taskId>', views.get_user_answer, name='get-user-answer'),
    path('api/olympiad', views.olympiad_view.as_view(), name='olympiad'),
    path("api/refresh", views.RefreshTokenView.as_view(), name="refresh_token"),
    path('api/check-olympiad', views.check_olympiad, name='check-olympiad'),
    re_path(r'^(?!api/).*$', views.index),
]
